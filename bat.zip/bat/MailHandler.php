<?php

session_start();
require 'phpmailer/PHPMailer-master/PHPMailerAutoload.php';

if(isset($_POST['name'],$_POST['email'],$_POST['comment'])){
   $fields = [
   'name' => $_POST['name'],
   'email' => $_POST['email'],
   'msg' => $_POST['comment']
   ];

   foreach($fields as $field => $data) {

   }
   if(empty($errors)){
    	$m = new PHPMailer;
    	$m->isSMTP();
    	$m->SMPTAuth = true;
    	$m->Username = 'droneint';                          // SMTP username
	$m->Password = '65J66qzfVu';                        // SMTP password
	$m->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
	$m->Port = 587;                                    // TCP port to connect to
	$m->setFrom('mail@droneinternational.com.sg', 'information');
	$m->addAddress('recieve@droneinternational.com.sg');               // Name is optional
   	// Optional name
	$m->isHTML(true);                                  // Set email format to HTML
	$m-> Subject = 'Contact Form Submitted';
	$m->Body = 'From: ' . $fields['name'] . '(' . $fields['email'] . ')<p>' . $fields['msg'] . '</p>';

	$m->FromName = 'Information';

	if($m->send()){
	  echo 'Your message has been sent. We will respond to you as soon as we can. Cheers!';
	}
	else{
	echo 'something went wrong!';
	}
   }

}
else{
$errors[]='Something went wrong';
}
$_SESSION['errors']= $errors;
$_SESSION['fields']= $fields;